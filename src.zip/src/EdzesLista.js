import React, { useEffect, useState } from "react";
import axios from "axios";

const EdzesLista = () => {
  const [edzesek, setEdzesek] = useState([]);

  useEffect(() => {
    fetchEdzesek();
  }, []);

  const fetchEdzesek = async () => {
    try {
      const response = await axios.get("http://localhost:8000/api/edzesek");
      setEdzesek(response.data);
    } catch (error) {
      console.error("Hiba az edzések lekérésekor:", error);
    }
  };

  return (
    <div>
      <h2>Edzések listája</h2>
      {edzesek.length === 0 ? (
        <p>Nincsenek edzések.</p>
      ) : (
        <ul>
          {edzesek.map((edzes) => (
            <li key={edzes.id}>
              <strong>{edzes.jatekos_nev}</strong> - {edzes.datum} - {edzes.edzes_tipus} - {edzes.idotartam_perc} perc
              {edzes.megjegyzes && <p>Megjegyzés: {edzes.megjegyzes}</p>}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default EdzesLista;
