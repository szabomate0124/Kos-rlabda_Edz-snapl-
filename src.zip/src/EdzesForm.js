import React, { useState } from "react";
import axios from "axios";

const EdzesForm = ({ onEdzesHozzaadva }) => {
  const [jatekosNev, setJatekosNev] = useState("");
  const [datum, setDatum] = useState("");
  const [edzesTipus, setEdzesTipus] = useState("");
  const [idotartam, setIdotartam] = useState("");
  const [megjegyzes, setMegjegyzes] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post("http://localhost:8000/api/edzesek", {
        jatekos_nev: jatekosNev,
        datum: datum,
        edzes_tipus: edzesTipus,
        idotartam_perc: parseInt(idotartam),
        megjegyzes: megjegyzes,
      });

      onEdzesHozzaadva(response.data);
      setJatekosNev("");
      setDatum("");
      setEdzesTipus("");
      setIdotartam("");
      setMegjegyzes("");
    } catch (error) {
      console.error("Hiba az edzés mentésekor:", error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Új edzés hozzáadása</h2>
      <input placeholder="Játékos neve" value={jatekosNev} onChange={(e) => setJatekosNev(e.target.value)} required />
      <input type="date" placeholder="Dátum" value={datum} onChange={(e) => setDatum(e.target.value)} required />
      <input placeholder="Edzés típusa" value={edzesTipus} onChange={(e) => setEdzesTipus(e.target.value)} required />
      <input type="number" placeholder="Időtartam (perc)" value={idotartam} onChange={(e) => setIdotartam(e.target.value)} required />
      <input placeholder="Megjegyzés" value={megjegyzes} onChange={(e) => setMegjegyzes(e.target.value)} />
      <button type="submit">Mentés</button>
    </form>
  );
};

export default EdzesForm;
