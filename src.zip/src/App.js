import React, { useState } from "react";
import EdzesLista from "./EdzesLista";
import EdzesForm from "./EdzesForm";

function App() {
  const [frissites, setFrissites] = useState(0);

  const handleEdzesHozzaadva = () => {
    setFrissites((prev) => prev + 1);
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>Kosárlabda Edzésnapló</h1>
      <EdzesForm onEdzesHozzaadva={handleEdzesHozzaadva} />
      <EdzesLista key={frissites} />
    </div>
  );
}

export default App;
