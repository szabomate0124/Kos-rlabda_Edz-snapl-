<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Edzes;

class EdzesController extends Controller
{
    // Összes edzés lekérése
    public function index()
    {
        return response()->json(Edzes::all());
    }

    // Új edzés mentése
    public function store(Request $request)
    {
        $validated = $request->validate([
            'jatekos_nev' => 'required|string|max:100',
            'datum' => 'required|date',
            'edzes_tipus' => 'required|string|max:100',
            'idotartam_perc' => 'required|integer|min:1',
            'megjegyzes' => 'nullable|string'
        ]);

        $edzes = Edzes::create($validated);
        return response()->json($edzes, 201);
    }

    // Szűrés játékos neve alapján
    public function filterByJatekos($nev)
    {
        return response()->json(Edzes::where('jatekos_nev', $nev)->get());
    }

    // Szűrés dátum alapján
    public function filterByDatum($datum)
    {
        return response()->json(Edzes::where('datum', $datum)->get());
    }

    // Szűrés időtartam alapján
    public function filterByIdotartam($min, $max)
    {
        return response()->json(Edzes::whereBetween('idotartam_perc', [$min, $max])->get());
    }
}
