<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Edzes extends Model
{
    use HasFactory;

    // Itt adjuk meg a tényleges táblanevet
    protected $table = 'edzesek';

    protected $fillable = [
        'jatekos_nev',
        'datum',
        'edzes_tipus',
        'idotartam_perc',
        'megjegyzes'
    ];
}
